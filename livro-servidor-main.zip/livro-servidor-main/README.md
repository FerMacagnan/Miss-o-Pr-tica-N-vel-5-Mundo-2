# Trabalho da faculdade nível 5
## Missão Prática | Nível 5 | Mundo 2
Sobre o trabalho: Servidor baseado em Express e Mongoose, acessando o banco de dados MongoDB, e front-ends baseados em React JS, Next JS e Angular.
